export const CUSTOM_NAME = 'Anubis Sabe Engineering For Plastic';
